        <tr> <!-- Footer -->
          <td>
            ...
          </td>
        </tr>
      </table> <!-- End: Content table -->
    </td>
  </tr>
</table> <!-- /#backgroundTable -->
</body>
</html>