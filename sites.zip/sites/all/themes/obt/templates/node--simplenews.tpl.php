<?php 
/*
Just for testing: this is never used in the site nor in the email.
*/

include_once('simplenews-newsletter-body.tpl.php');
include_once('simplenews-newsletter-footer.tpl.php');