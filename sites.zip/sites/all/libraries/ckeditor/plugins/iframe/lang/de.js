﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'de', {
	border: 'Rahmen anzeigen',
	noUrl: 'Bitte geben Sie die IFrame-URL an',
	scrolling: 'Rollbalken anzeigen',
	title: 'IFrame-Eigenschaften',
	toolbar: 'IFrame'
});
