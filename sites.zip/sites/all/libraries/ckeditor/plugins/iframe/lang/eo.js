﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'eo', {
	border: 'Montri borderon de kadro (frame)',
	noUrl: 'Bonvolu entajpi la retadreson de la ligilo al la enlinia kadro (IFrame)',
	scrolling: 'Ebligi rulumskalon',
	title: 'Atributoj de la enlinia kadro (IFrame)',
	toolbar: 'Enlinia kadro (IFrame)'
});
