﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'pl', {
	border: 'Pokaż obramowanie obiektu IFrame',
	noUrl: 'Podaj adres URL elementu IFrame',
	scrolling: 'Włącz paski przewijania',
	title: 'Właściwości elementu IFrame',
	toolbar: 'IFrame'
});
