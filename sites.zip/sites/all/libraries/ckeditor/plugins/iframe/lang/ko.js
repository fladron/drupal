﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ko', {
	border: '프레임 테두리 표시',
	noUrl: 'iframe 대응 URL을 입력해주세요.',
	scrolling: '스크롤바 사용',
	title: 'IFrame 속성',
	toolbar: 'IFrame'
});
