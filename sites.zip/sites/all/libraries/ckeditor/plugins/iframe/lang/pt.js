﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'pt', {
	border: 'Mostrar a borda da Frame',
	noUrl: 'Por favor escreva o URL da iframe',
	scrolling: 'Activar barras de deslocamento',
	title: 'Propriadades da IFrame',
	toolbar: 'IFrame'
});
