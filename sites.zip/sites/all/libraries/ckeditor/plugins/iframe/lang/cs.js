﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'cs', {
	border: 'Zobrazit okraj',
	noUrl: 'Zadejte prosím URL obsahu pro IFrame',
	scrolling: 'Zapnout posuvníky',
	title: 'Vlastnosti IFrame',
	toolbar: 'IFrame'
});
