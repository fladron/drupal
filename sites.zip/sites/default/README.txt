/*
* In settings.php we must put the following at the end of the file:
*/
 
/**
 * Site environment
 * dev, pre or pro
 */
$conf['environment'] = 'dev';

/**
 * Error reporting
 */
/*error_reporting(1);
$conf['error_level'] = 2;
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);*/